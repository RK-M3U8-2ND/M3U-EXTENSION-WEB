let isRecording = false;
let mediaRecorder;
let recordedChunks = [];

chrome.browserAction.onClicked.addListener(function(tab) {
    if (isRecording) {
        mediaRecorder.stop();
        chrome.tabs.sendMessage(tab.id, { action: 'stop' });
        isRecording = false;
    } else {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'start' });
        });
        isRecording = true;
    }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action == 'start') {
        navigator.mediaDevices.getUserMedia({ video: true, audio: true })
            .then(stream => {
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.ondataavailable = function(event) {
                    recordedChunks.push(event.data);
                };
                mediaRecorder.onstop = function() {
                    let blob = new Blob(recordedChunks, { type: 'video/mp4' });
                    let url = URL.createObjectURL(blob);
                    chrome.downloads.download({
                        url: url,
                        filename: "recorded_video.mp4",
                        saveAs: true
                    });
                };
                mediaRecorder.start();
            })
            .catch(function(error) {
                console.error("Error in starting media recording", error);
            });
    }
    sendResponse({});
});