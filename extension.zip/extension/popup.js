document.getElementById('startStopBtn').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'start' });
});